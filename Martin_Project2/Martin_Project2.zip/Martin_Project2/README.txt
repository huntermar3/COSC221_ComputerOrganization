CREATOR: HUNTER MARTIN
COURSE: COSC 221 W/24 DR.POH
3-25-24
DESCRIPTION: We are creating a LC3 program that converting the corresponding ASCII values {1,2,3,4,5} to their respective 2's complement value. We must use all 3 addressing modes. 

-How do I run this program?
	Unzip the folder submitted. You can directly just copy and paste the source code into LC3. 
	
