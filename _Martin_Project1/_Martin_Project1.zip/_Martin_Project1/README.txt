CREATOR: HUNTER MARTIN
COURSE: COCS 221 W'24 DR.POH
2-5-24
DESCRIPTION: It is a calculator based application. It is controlled by a switch and if user presses 1 it converts a decimal number into its signed magnitude, ones and two complement, and excess 128 notation. If the user goes through the switch and they select 2 it converts a 8 bit sequence of numbers into its corresponding signed magnitude, ones and twos complement, and excess 128 notation.



-What language was this program coded in?
	This program was coded in Java.

-How do I run this program?
	Unzip the folder submitted. Then either you can open on a text editor, or an IDE of your choosing. I created this program on Eclipse , so you can just open program on Eclipse.
	

-Is there any specific inputs?
	When using converting the 8 bit to decimal, please don't use any spaces. Example, "01101110".If you do accidentally type 9 bits or 7 bits, there is a check in place to deal with anything less than or greater than 8. If you use other digits other than 0s and 1s the program will prompt you back to the menu. For prompt 1, say you want 25 in 8 bit value. Just type "25" or vice versa "-25".