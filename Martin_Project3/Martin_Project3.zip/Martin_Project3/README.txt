CREATOR: HUNTER MARTIN
COURSE: COSC 221 W/24 DR.POH
4-13-24
DESCRIPTION: I created a LC3 program that counts the number of evens and odds of a string of numbers. It has all the required data validation.
overall, it explores everything we have learned this semester.

-How do I run this program?
	Unzip the folder submitted. You can just directly copy and paste the code given in "Martin_Project3.txt" to LC3